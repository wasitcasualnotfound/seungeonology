const KEY='seungeonology_guestbook_v1';
const form=document.getElementById('guestForm');
const entries=document.getElementById('guestEntries');
function readEntries(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return []}}
function renderEntries(){const list=readEntries();entries.innerHTML='';if(!list.length){entries.innerHTML='<div class="empty-note">YOUR NOTE COULD BE THE FIRST ONE HERE ♡</div>';return}list.slice().reverse().forEach(item=>{const article=document.createElement('article');article.className='entry';const name=document.createElement('strong');name.textContent=item.name;const time=document.createElement('time');time.textContent=item.date;const message=document.createElement('p');message.textContent=item.message;article.append(name,time,message);entries.append(article)})}
form.addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('guestName').value.trim();const message=document.getElementById('guestMessage').value.trim();if(!name||!message)return;const list=readEntries();list.push({name,message,date:new Date().toLocaleDateString()});localStorage.setItem(KEY,JSON.stringify(list.slice(-50)));form.reset();renderEntries()});
renderEntries();
